create definer = root@localhost view user_order as
select `flowers`.`orders`.`user_id`        AS `user_id`,
       `flowers`.`users`.`user_name`       AS `user_name`,
       `flowers`.`users`.`password`        AS `password`,
       `flowers`.`users`.`sex`             AS `sex`,
       `flowers`.`users`.`birthday`        AS `birthday`,
       `flowers`.`users`.`tel`             AS `tel`,
       `flowers`.`users`.`mail`            AS `mail`,
       `flowers`.`users`.`grade`           AS `grade`,
       `flowers`.`users`.`record_date`     AS `record_date`,
       `flowers`.`orders`.`order_id`       AS `order_id`,
       `flowers`.`orders`.`touser_name`    AS `touser_name`,
       `flowers`.`orders`.`touser_tel`     AS `touser_tel`,
       `flowers`.`orders`.`touser_address` AS `touser_address`,
       `flowers`.`orders`.`totalprice`     AS `totalprice`,
       `flowers`.`orders`.`od_createtime`  AS `od_createtime`,
       `flowers`.`orders`.`status`         AS `status`,
       `flowers`.`orders`.`od_remark`      AS `od_remark`
from (`flowers`.`orders`
         join `flowers`.`users`)
where (`flowers`.`orders`.`user_id` = `flowers`.`users`.`user_id`);

