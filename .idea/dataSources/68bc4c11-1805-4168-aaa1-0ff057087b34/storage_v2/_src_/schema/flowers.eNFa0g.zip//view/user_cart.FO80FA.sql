create definer = root@localhost view user_cart as
select `flowers`.`cart`.`user_id`       AS `user_id`,
       `flowers`.`users`.`user_name`    AS `user_name`,
       `flowers`.`users`.`password`     AS `password`,
       `flowers`.`users`.`sex`          AS `sex`,
       `flowers`.`users`.`birthday`     AS `birthday`,
       `flowers`.`users`.`tel`          AS `tel`,
       `flowers`.`users`.`mail`         AS `mail`,
       `flowers`.`users`.`grade`        AS `grade`,
       `flowers`.`users`.`record_date`  AS `record_date`,
       `flowers`.`cart`.`flowercode`    AS `flowercode`,
       `flowers`.`flower`.`type`        AS `type`,
       `flowers`.`flower`.`flower_name` AS `flower_name`,
       `flowers`.`flower`.`material`    AS `material`,
       `flowers`.`flower`.`pack`        AS `pack`,
       `flowers`.`flower`.`descs`       AS `descs`,
       `flowers`.`flower`.`price`       AS `price`,
       `flowers`.`flower`.`discount`    AS `discount`,
       `flowers`.`flower`.`image`       AS `image`,
       `flowers`.`flower`.`deliverarea` AS `deliverarea`,
       `flowers`.`flower`.`amount`      AS `amount`,
       `flowers`.`flower`.`createtime`  AS `createtime`,
       `flowers`.`flower`.`remark`      AS `remark`,
       `flowers`.`cart`.`cart_id`       AS `cart_id`,
       `flowers`.`cart`.`count`         AS `count`,
       `flowers`.`cart`.`totalprice`    AS `totalprice`
from ((`flowers`.`cart` join `flowers`.`flower`)
         join `flowers`.`users`)
where ((`flowers`.`cart`.`user_id` = `flowers`.`users`.`user_id`) and
       (`flowers`.`cart`.`flowercode` = `flowers`.`flower`.`flowercode`));

