create definer = root@localhost view order_orderlist as
select `flowers`.`orderlist`.`od_id`       AS `od_id`,
       `flowers`.`orderlist`.`order_id`    AS `order_id`,
       `flowers`.`orderlist`.`flowercode`  AS `flowercode`,
       `flowers`.`orderlist`.`count`       AS `count`,
       `flowers`.`orderlist`.`summary`     AS `summary`,
       `flowers`.`orders`.`user_id`        AS `user_id`,
       `flowers`.`orders`.`touser_name`    AS `touser_name`,
       `flowers`.`orders`.`touser_tel`     AS `touser_tel`,
       `flowers`.`orders`.`touser_address` AS `touser_address`,
       `flowers`.`orders`.`totalprice`     AS `totalprice`,
       `flowers`.`orders`.`od_createtime`  AS `od_createtime`,
       `flowers`.`orders`.`status`         AS `status`,
       `flowers`.`orders`.`od_remark`      AS `od_remark`,
       `flowers`.`users`.`user_name`       AS `user_name`,
       `flowers`.`users`.`password`        AS `password`,
       `flowers`.`users`.`sex`             AS `sex`,
       `flowers`.`users`.`birthday`        AS `birthday`,
       `flowers`.`users`.`tel`             AS `tel`,
       `flowers`.`users`.`mail`            AS `mail`,
       `flowers`.`users`.`grade`           AS `grade`,
       `flowers`.`users`.`record_date`     AS `record_date`,
       `flowers`.`flower`.`type`           AS `type`,
       `flowers`.`flower`.`flower_name`    AS `flower_name`,
       `flowers`.`flower`.`material`       AS `material`,
       `flowers`.`flower`.`pack`           AS `pack`,
       `flowers`.`flower`.`descs`          AS `descs`,
       `flowers`.`flower`.`price`          AS `price`,
       `flowers`.`flower`.`discount`       AS `discount`,
       `flowers`.`flower`.`image`          AS `image`,
       `flowers`.`flower`.`deliverarea`    AS `deliverarea`,
       `flowers`.`flower`.`amount`         AS `amount`,
       `flowers`.`flower`.`createtime`     AS `createtime`,
       `flowers`.`flower`.`remark`         AS `remark`
from (((`flowers`.`orderlist` join `flowers`.`orders`) join `flowers`.`users`)
         join `flowers`.`flower`)
where ((`flowers`.`orderlist`.`order_id` = `flowers`.`orders`.`order_id`) and
       (`flowers`.`orders`.`user_id` = `flowers`.`users`.`user_id`) and
       (`flowers`.`orderlist`.`flowercode` = `flowers`.`flower`.`flowercode`));

